package com.bangkit.kukus

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class OnClickedHealthyFoodActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_on_clicked_healthy_food)
    }
}