package com.bangkit.kukus.ui.diary

class DiaryViewModel {
}