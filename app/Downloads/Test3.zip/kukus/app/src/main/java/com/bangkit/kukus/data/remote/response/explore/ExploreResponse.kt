package com.bangkit.kukus.data.remote.response.explore

class ExploreResponse : ArrayList<ExploreResponseItem>()